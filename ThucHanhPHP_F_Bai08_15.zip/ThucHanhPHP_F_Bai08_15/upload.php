<?php
function saveImage(array $file, string $directory, bool $allowPng = false): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Hãy chọn một ảnh hợp lệ và kiểm tra giới hạn tải lên của PHP.');
    }
    if ($file['size'] > 5000000 || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Ảnh phải có dung lượng tối đa 5.000.000 byte.');
    }

    $allowed = ['image/jpeg' => 'jpg', 'image/gif' => 'gif'];
    if ($allowPng) {
        $allowed['image/png'] = 'png';
    }
    $type = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$type]) || @getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException($allowPng ? 'Chỉ chấp nhận ảnh JPG, GIF và PNG.' : 'Chỉ chấp nhận ảnh JPG và GIF.');
    }
    if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
        throw new RuntimeException('Không thể tạo thư mục lưu ảnh.');
    }

    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$type];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $name)) {
        throw new RuntimeException('Không lưu được ảnh.');
    }
    return $name;
}

