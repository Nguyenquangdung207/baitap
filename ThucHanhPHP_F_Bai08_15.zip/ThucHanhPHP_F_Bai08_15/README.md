# Thực hành PHP từ Bài 8 đến Bài 15

Bộ lời giải gồm 8 bài PHP. Mỗi thư mục từ `bai08` đến `bai15` chứa một bài. Trang `index.php` ở thư mục gốc là danh mục. Mở mã bài theo đường dẫn `baiXX/index.php`.

## Chạy trên XAMPP

1. Giải nén và đặt thư mục `ThucHanhPHP_F_Bai08_15` trong thư mục `htdocs` của XAMPP, ví dụ `D:\XAMPP\htdocs\ThucHanhPHP_F_Bai08_15`.
2. Trong XAMPP Control Panel, bật **Apache** và **MySQL**. Trang chính là `http://localhost/ThucHanhPHP_F_Bai08_15/` nếu Apache dùng cổng 80. Nếu Apache chạy cổng khác, thêm cổng vào URL.
3. Mở phpMyAdmin của XAMPP, chọn **Import**, chọn `database.sql` rồi chạy. Tệp này tạo cơ sở dữ liệu riêng `thuchanh_php_f_bai08_15` với bảng và dữ liệu mẫu. Bài 10.3, 11, 12, 13 và 15 dùng cơ sở dữ liệu này.
4. Kết nối mặc định là MySQL trên `127.0.0.1:3306` với tài khoản cục bộ mặc định của XAMPP. Nếu máy có cấu hình khác, đặt `PHPF_DB_PORT`, `PHPF_DB_USER` và `PHPF_DB_PASSWORD` trong môi trường tiến trình chạy PHP. Xem `db.php` để biết tên biến và giá trị mặc định.

Tài khoản mẫu **chỉ dùng cho bài 10.3** là `thuchanh` / `demo-php-2026`. Cơ sở dữ liệu lưu giá trị băm. Khi đăng nhập thành công, Session lưu tên người dùng để xác định quyền truy cập trang quản trị.

## Thử từng bài

| Bài | Cách thử và kết quả |
| --- | --- |
| 08 | Cách 1 dùng JavaScript thay một ô. Cách 2 dùng lớp PHP gọi JavaScript để thay cả hai ô. Định dạng chữ rồi gửi để xem HTML mà PHP nhận. |
| 09 | Chọn một ảnh JPG/GIF mẫu, gửi và xem ảnh. Đổi tên một tệp văn bản thành `.jpg` rồi thử lại để xem thông báo từ chối. |
| 10 | Khởi tạo tên và tuổi. Xóa biến tên và xem tuổi còn lại. Tăng bộ đếm. Mở trang quản trị trước và sau khi đăng nhập tài khoản mẫu. |
| 11 | Xem trang 1, trang 2 và trang 20. Có 200 tin mẫu, 10 tin mỗi trang. |
| 12 | Chọn sản phẩm và gửi 5 sao. Số lượt 5 sao của sản phẩm tăng thêm 1. |
| 13 | Mở `rss.php` để xem XML RSS 2.0 gồm bốn bản tin. |
| 14 | Nhập một mã sai, sau đó nhập đúng mã mới trong ảnh. Mỗi mã dùng một lần. |
| 15 | Xem kết quả trước khi bình chọn, sau đó chọn một phương án. Kiểm tra số lượt, phần trăm và tổng lượt. |

## Ghi chú khi đọc mã

- `common.php` gom phần hiển thị chung, kiểm tra đầu vào và hàm Session. Biểu mẫu thay đổi dữ liệu có mã kiểm tra để chống gửi yêu cầu từ trang khác.
- `db.php` kết nối MySQL qua PDO. Ở bài 12, câu lệnh cập nhật nhận giá trị qua tham số. Ở bài 15, một giao dịch cập nhật cả phương án và tổng lượt.
- Bài 9 còn chịu giới hạn `upload_max_filesize` và `post_max_size` của PHP.
- Bài 8 đóng gói CKEditor 4.22.1 Basic để giữ hai API của đề. Bản cộng đồng CKEditor 4 đã hết hỗ trợ và chỉ dùng trong bài chạy cục bộ. Xem giấy phép trong `bai08/ckeditor/LICENSE.md`. [Thông tin từ CKSource](https://ckeditor.com/docs/ckeditor4/latest/support/index.html)
- Bài 12 dùng hình minh họa SVG tự tạo cho ba sản phẩm. Bài 14 xuất PNG khi PHP có GD và xuất SVG trên cấu hình thiếu GD. CAPTCHA này phục vụ thực hành Session.

